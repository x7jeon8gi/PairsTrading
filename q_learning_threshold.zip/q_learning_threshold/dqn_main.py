from agent import DQNAgent
from environment import TradingEnvironment
from universal_approximator import Simple_QNetwork
import torch
import torch.nn as nn
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import yaml
import os
import tqdm
from collections import deque
import wandb

class Trainer:
    def __init__(self, config):
        self.config = config
        self.device = config['train']['device']
        self.epsilon_decay = config['train']['epsilon_decay']
        self.save_name = config['train']['save_name']
        wandb.init(project='q_learning_threshold', name=self.save_name, config=config)

        # * Environment
        self.env = TradingEnvironment(
            start_month='1990-01' ,
            threshold_list=self.config['DQN']['threshold_list'],
            monthlyClusterDir= self.config['train']['monthlyClusterDir'],
            reward_scaling=self.config['DQN']['reward_scaling'])

        # * Agent
        self.agent = DQNAgent(state_size = self.config['DQN']['state_size'],
                              action_size = len(self.config['DQN']['threshold_list']),
                              gamma = self.config['DQN']['gamma'],
                              buffer_size = self.config['DQN']['buffer_size'],

                              hidden_size = self.config['train']['hidden_dim'],
                              batch_size = self.config['train']['batch_size'],
                              lr = self.config['train']['lr'],
                              T_max= (self.config['train']['n_episodes'] * self.config['train']['batch_size']),
                              # T_max=self.config['train']['num_epochs'] * (np.ceil(n_train_samples / config['train']['batch_size']) + 1))
        
                              device = self.device,
                              simple=False)

        # * Training
        self.n_episodes = self.config['train']['n_episodes']
        self.patience = 300
        
    def train(self):
        save_path = f'./res/q_learning_threshold/models/{self.save_name}.pt'
        epsilon = self.config['train']['epsilon']
        no_improve_count = 0
        max_reward = -1000
        loss_list = deque(maxlen=100)

        # * Training
        scores = []
        p_bar = tqdm.tqdm(range(self.n_episodes))

        for e in range(self.n_episodes):
            state = self.env.reset()
            loss = None

            while True:
                action = self.agent.act(state, epsilon) # * agent
                next_state, reward, done = self.env.step(action) # * env
                self.agent.memory.push(state, action, reward, next_state, done)
                state = next_state
                if done:
                    next_state = None
                    if self.env.current_portfolio_value > 65 :
                        reward = 10
                    elif self.env.current_portfolio_value < 50 :
                        reward = -10
                    else :
                        reward = 0
                    break

            scores.append(self.env.total_reward)

            if len(self.agent.memory) > config['train']['buffer_thres']:
                loss = self.agent.learn()

            epsilon = max(0.005, epsilon * self.epsilon_decay)

            # wandb
            wandb.log({'episode': e,
                       'total_reward': self.env.total_reward,
                       'portfolio_value': self.env.current_portfolio_value,
                       'epsilon': epsilon,
                       'loss': loss if loss is not None else 'N/A'})
            
            # save model if loss is improved
            if max_reward < self.env.current_portfolio_value:
                max_reward = self.env.current_portfolio_value

                if not os.path.exists('./res/q_learning_threshold/models'):
                    os.makedirs('./res/q_learning_threshold/models')
                torch.save(self.agent.model.state_dict(), save_path)
                print(f"New Model saved at {save_path}")

            # Target model update
            if e % 20 == 0:
                self.agent.model_target.load_state_dict(self.agent.model.state_dict())
            if e % 10 == 0:
                print(f" Episode: {e}, Total Reward: {self.env.total_reward}, \
                        N_buffer: {len(self.agent.memory)}, \
                        Epsilon: {epsilon}, \
                        Portfolio Value: {self.env.current_portfolio_value}, \
                        Loss: {loss if loss is not None else 'N/A'}")        
                    
            p_bar.update(1)

        # save score
        scores = pd.DataFrame(scores)
        scores.to_csv(f'./res/q_learning_threshold/scores_thres_{self.save_name}.csv')

        # * Plot
        plt.plot(scores)
        plt.title("Score")
        # save plot
        plt.savefig(f'./res/q_learning_threshold/scores_thres_{self.save_name}.png')
        plt.close()
        
        wandb.finish()
if __name__ == "__main__":
    # * Config
    with open('./q_learning_threshold/dqn_config.yaml', 'r') as f:
        config = yaml.load(f, Loader=yaml.FullLoader)

    # * Trainer
    trainer = Trainer(config)
    trainer.train()