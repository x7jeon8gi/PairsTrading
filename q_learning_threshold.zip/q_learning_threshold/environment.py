import numpy as np
import pandas as pd
import os
import sys
from glob import glob
from scipy.stats.mstats import winsorize
import logging
import copy

sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))

class TradingEnvironment:
    def __init__(self, equityMonthlyReturns=None, monthlyClusterDir=None, threshold_list = None, start_month = '1990-01', reward_scaling=10):
        
        self.reward_scaling = reward_scaling
        if threshold_list is None:
            self.thresholds = [1, 1.3, 1.5, 1.8, 2, 2.3, 2.5, 2.8]
        else:
            self.thresholds = threshold_list
        if equityMonthlyReturns is None:
            equityMonthlyReturns = './q_learning_threshold/mom1_data_combined_adj_close.csv'
        self.equityMonthlyReturns = pd.read_csv(equityMonthlyReturns, index_col=0)
        
        # start_month 이후의 데이터만 사용
        filtered_columns = [col for col in self.equityMonthlyReturns.columns if col >= start_month]
        self.equityMonthlyReturns = self.equityMonthlyReturns[filtered_columns]
    
        # winsorize
        df_filled_zeros = self.equityMonthlyReturns.fillna(0)
        df_winsorized_filled_zeros = df_filled_zeros.apply(lambda x: pd.Series(winsorize(x, limits=[0.01, 0.01]), index=x.index))
        self.equityMonthlyReturns = df_winsorized_filled_zeros.where(self.equityMonthlyReturns.notna())

        # * 환경 변수
        self.index_fund = pd.read_csv('./q_learning_threshold/sp500.csv', index_col=0)

        if monthlyClusterDir is None:
            # 매 달 클러스터링 결과 (Monthly Clustering)
            monthlyClusterDir = './res/predictions/10_characteristics_us_batch_32_bins_64_hidden_128'
        self.monthlyClusterDir = monthlyClusterDir

        # * 학습된 클러스터링의 결과
        self.cluster_results = glob(monthlyClusterDir + '/*')
        self.cluster_results.sort()
        
        self.current_step = 0
        
    def reset(self):
        self.current_step = 0
        self.total_reward = 0
        self.current_portfolio_value = 0
        return self._get_state()
    
    def _get_state(self):
        """ 
        STATE 정의
        1. 현재 자산의 갯수
        2. 현재 S&P의 수익률
        3. 현재 S&P의 변동성
        """

        # 이 달의 데이터 및 수익률 계산
        currentMonth = self.cluster_results[self.current_step] # 현재 달의 클러스터링 결과: './.csv' 파일
        self.currentMonth_name = currentMonth.split('/')[-1].split('.')[0] # e.g 2001-01
        self.nextMonth_name = self.cluster_results[self.current_step + 1].split('/')[-1].split('.')[0] # e.g 2001-02
        currentMonth_data = pd.read_csv(currentMonth, index_col=0) # 현재 달의 클러스터링 결과 .csv 파일 읽기
        self.currentMonth_data = currentMonth_data
        self.currentMonth_data.sort_values(by='mom1', ascending=False, inplace=True) # mom1 기준으로 내림차순 정렬
              
        # S&P500 데이터
        sp500_data = self.index_fund.loc[self.currentMonth_name]
        current_sp_return = sp500_data['Monthly Returns']
        current_sp_volatility = sp500_data['Monthly Volatility']
        current_number_of_assets = sp500_data['Number of Assets']
        current_month = sp500_data['month_fraction']
        return np.array([current_number_of_assets, current_sp_return, current_sp_volatility, current_month])

    def _take_action(self, action):
        """
        ACTION 정의
        """
        thresholds = self.thresholds
        threshold = thresholds[action]

        equityReturnsCopy = copy.deepcopy(self.equityMonthlyReturns)

        # 각 클러스터별로 자산 그룹화 및 투자 결정 (* 클러스터를 도는 것)
        for _, group in self.currentMonth_data.groupby('clusters'):
            
            returnsAscend = group.sort_values(by='mom1', ascending=True)['mom1']
            returnsDescend = group.sort_values(by='mom1', ascending=False)['mom1']
            spreadArray = returnsDescend.values - returnsAscend.values

            group['spread'] = spreadArray
            spreadStd = group['spread'].std()

            inPortfolio = group['spread'].abs() > spreadStd * threshold
            Long_or_Short = (-group['spread'] / (group['spread'].abs()))

            long_firms = group[inPortfolio & (Long_or_Short == 1)]
            short_firms = group[inPortfolio & (Long_or_Short == -1)]
            cash_firms = group[~inPortfolio]

            # 해당 자산들에 대해 연산 수행
            equityReturnsCopy.loc[short_firms.index, self.nextMonth_name] *= -1
            equityReturnsCopy.loc[cash_firms.index, self.nextMonth_name] = 0

        # 포트폴리오 가치 계산
        earning_with_cash = equityReturnsCopy.loc[:, self.nextMonth_name]
        earning = earning_with_cash[earning_with_cash != 0].dropna().mean()
        
        log_return = np.log(1+earning)
        self.current_portfolio_value = np.exp(np.log(1 + self.current_portfolio_value) + log_return) - 1

        reward = earning * self.reward_scaling # 스케일링

        if reward < 0:
            reward = -1

        return reward  
        
    def step(self, action):

        reward = self._take_action(action)
        self.total_reward += reward
        
        self.current_step += 1
        # logging.info(f"Step: {self.current_step}, Reward: {reward}, Total Reward: {self.total_reward}, Portfolio Value: {self.current_portfolio_value}")
        done = self.current_step >= len(self.cluster_results) - 1

        self.done = done
        next_state = self._get_state() if not done else None 
        return next_state, reward, done