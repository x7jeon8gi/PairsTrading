import torch
import torch.nn as nn

class Simple_QNetwork(nn.Module):
    """
    매우 간단한 아키텍처
    Baseline으로 사용
    """
    def __init__(self, state_size, action_size=8, hidden_sizes=[64, 64], dropout_rate=0.1, stack_layers=True):
        super().__init__()
        """
        Discretizaition을 통해 continuous action space를 discrete action space로 변환
        Action [1, 1.3, 1.5, 1.8, 2, 2.3, 2.5, 2.8]
        """

        if stack_layers:

            self.layers = nn.Sequential(

                nn.Linear(state_size, hidden_sizes[0]),

                nn.GELU(),
                nn.Dropout(dropout_rate),

                nn.Linear(hidden_sizes[0], hidden_sizes[1]),

                nn.GELU(),
                nn.Dropout(dropout_rate),

                nn.Linear(hidden_sizes[1], action_size),
                # nn.Softmax()
            )

        else:
            #* More simple
            self.layers = nn.Sequential(
                
                nn.Linear(state_size, hidden_sizes[0]),
                nn.GELU(),
                nn.Dropout(dropout_rate),

                nn.Linear(hidden_sizes[0], action_size),
                # nn.Softmax()
            )

    def forward(self, state):
        logit = self.layers(state)
        return logit # scale up to 3


class Simple_QNetwork2(nn.Module):
    """
    매우 간단한 아키텍처
    Baseline으로 사용
    """
    def __init__(self, state_size, action_size=8, hidden_sizes=[64, 64], stack_layers=True):
        super().__init__()
        """
        Discretizaition을 통해 continuous action space를 discrete action space로 변환
        Action [1, 1.3, 1.5, 1.8, 2, 2.3, 2.5, 2.8]
        """

        if stack_layers:

            self.layers = nn.Sequential(
                nn.Linear(state_size, hidden_sizes[0]),
                nn.GELU(),
                nn.Linear(hidden_sizes[0], hidden_sizes[1]),
                nn.GELU(),
                nn.Linear(hidden_sizes[1], action_size),
                # nn.Softmax()
            )

        else:
            #* More simple
            self.layers = nn.Sequential(
                nn.Linear(state_size, hidden_sizes[0]),
                nn.GELU(),
                nn.Linear(hidden_sizes[0], action_size),
                # nn.Softmax()
            )

    def forward(self, state):
        logit = self.layers(state)
        return logit # scale up to 3

