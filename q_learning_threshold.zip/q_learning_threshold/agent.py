import torch
import torch.nn as nn
import numpy as np
import random
from collections import deque
import torch.optim as optim
from universal_approximator import Simple_QNetwork, Simple_QNetwork2
from torch.optim.lr_scheduler import CosineAnnealingLR

class ReplayBuffer():
    """
    DQN의 핵심 성공 요소
    Experience Replay를 위한 Buffer
    """
    def __init__(self, capacity):
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size):
        return random.sample(self.buffer, batch_size)

    def __len__(self):
        return len(self.buffer)


class DQNAgent():
    def __init__(self,
                 state_size,
                 action_size,
                 hidden_size, 
                 batch_size, 
                 gamma,
                 lr, 
                 buffer_size,
                 T_max,
                 device='cuda',
                 simple=True):
        
        self.state_size = state_size
        self.action_size = action_size
        self.batch_size = batch_size
        self.gamma = gamma
        self.device = device
        self.T_max = T_max

        # Replay Buffer
        self.memory = ReplayBuffer(buffer_size)

        # Q-Network
        if simple:
            self.model = Simple_QNetwork2(state_size, action_size, hidden_sizes=[hidden_size, hidden_size], stack_layers=False)
            self.model_target = Simple_QNetwork2(state_size, action_size, hidden_sizes=[hidden_size, hidden_size], stack_layers=False)
            self.model_target.load_state_dict(self.model.state_dict())
        else:
            self.model = Simple_QNetwork2(state_size, action_size, hidden_sizes=[hidden_size, hidden_size], stack_layers=True)
            self.model_target = Simple_QNetwork2(state_size, action_size, hidden_sizes=[hidden_size, hidden_size], stack_layers=True)
            self.model_target.load_state_dict(self.model.state_dict())
        # GPU
        self.model.to(device)
        self.model_target.to(device)
        
        # Optimizer and Scheduler
        self.optimizer = optim.Adam(self.model.parameters(), lr=lr)
        self.scheduler = CosineAnnealingLR(self.optimizer, T_max=self.T_max)

    def act(self, state, epsilon):
        if random.uniform(0,1) > epsilon:
            state = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            self.model.eval()
            with torch.no_grad():
                q_values = self.model.forward(state)
            return np.argmax(q_values.cpu().detach().numpy())
        else:
            return random.randrange(self.action_size)

    def learn(self):
        if len(self.memory) < self.batch_size:
            return

        batch = self.memory.sample(self.batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)

        # 'None'인 next_states를 0으로 채운 배열로 대체
        next_states = [np.zeros(self.state_size) if s is None else s for s in next_states]

        # Convert to tensors
        states = torch.FloatTensor(np.array(states)).to(self.device)
        actions = torch.LongTensor(actions).to(self.device)
        rewards = torch.FloatTensor(rewards).to(self.device)
        next_states = torch.FloatTensor(np.array(next_states)).to(self.device)
        dones = torch.FloatTensor(dones).to(self.device)

        # Q-Learning (Target Network)
        self.model.eval()
        current_q_values = self.model(states).gather(1, actions.view(-1, 1)).squeeze(-1)

        with torch.no_grad():
            next_q_values = self.model_target(next_states).max(1).values
        expected_q_values = rewards + self.gamma * next_q_values * (1 - dones)

        # Loss and backpropagation
        self.model.train()
        loss = nn.SmoothL1Loss()(current_q_values, expected_q_values)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        self.scheduler.step()

        # logging
        return loss.item()