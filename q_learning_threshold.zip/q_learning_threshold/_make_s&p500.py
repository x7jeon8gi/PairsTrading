import yfinance as yf
import pandas as pd
import os

def get_snp():
    # Download S&P 500 data for monthly and daily intervals
    sp500_monthly = yf.download('^GSPC', start='1989-12-01', end='2022-08-31', interval='1mo')
    sp500_daily = yf.download('^GSPC', start='1989-12-01', end='2022-08-31', interval='1d')

    # Clean the data by dropping NaN values
    sp500_monthly.dropna(inplace=True)
    sp500_daily.dropna(inplace=True)

    # Calculate monthly returns
    sp500_monthly['Monthly Returns'] = sp500_monthly['Close'].pct_change()

    # Calculate daily returns
    sp500_daily['Daily Returns'] = sp500_daily['Close'].pct_change()

    # Group by Year and Month, and calculate standard deviation of daily returns
    sp500_daily['Year'] = sp500_daily.index.year
    sp500_daily['Month'] = sp500_daily.index.month
    monthly_volatility = sp500_daily.groupby(['Year', 'Month'])['Daily Returns'].std() * (12 ** 0.5)

    # Convert the MultiIndex to a single datetime index
    monthly_volatility.index = pd.to_datetime(monthly_volatility.index.map(lambda x: f"{x[0]}-{x[1]:02}"))
    monthly_volatility.index = monthly_volatility.index.strftime('%Y-%m')

    # Merge the monthly returns and monthly volatility data
    monthly_data = pd.DataFrame({'Monthly Returns': sp500_monthly['Monthly Returns']})
    monthly_data.index = monthly_data.index.strftime('%Y-%m')
    monthly_data = monthly_data.join(monthly_volatility.rename('Monthly Volatility'))

    monthly_data.dropna(inplace=True)
    monthly_data

    # Save the data to a CSV file
    current_path = os.getcwd()
    path = os.path.join(current_path, 'q_learning')
    if not os.path.exists(path):
        os.mkdir(path)
    monthly_data.to_csv(os.path.join(path, 'sp500_pre.csv'))

if __name__ == "__main__":
    get_snp()